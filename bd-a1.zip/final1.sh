#!/bin/bash

echo "Copying output files to host machine..."
cp /home/doc-bd-a1/*.txt /home/doc-bd-a1/*.png /home/doc-bd-a1/service-result/

echo "All output files have been copied to the host machine (service-result folder)."
